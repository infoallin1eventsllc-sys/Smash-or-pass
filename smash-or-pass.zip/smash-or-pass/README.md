# SMASH OR PASS 🔥

A full-featured dating app built with React + Vite, styled with Tailwind CSS.

## Screens
- **Discover** — Swipe cards (drag or tap buttons), smash/pass with animations
- **Match** — Confetti celebration screen when you match
- **Messages** — Inbox with unread indicators and group chats
- **Chat / DM** — Real-time-feel messaging with typing indicator and reactions
- **Profile** — Photo gallery, bio, tags, and action buttons

## Local Development

```bash
npm install
npm run dev
# → http://localhost:5173
```

## Docker Deployment

### Build & run with Docker Compose (recommended)
```bash
docker compose up -d --build
# → http://localhost:3000
```

### Build & run manually
```bash
docker build -t smash-or-pass .
docker run -d -p 3000:3000 --name smash-or-pass smash-or-pass
# → http://localhost:3000
```

### Stop
```bash
docker compose down
```

## Production build (without Docker)
```bash
npm run build        # outputs to /dist
npm run preview      # serves dist locally on port 3000
```

## Tech Stack
- React 18
- Vite 6
- Tailwind CSS 3
- Google Material Symbols
- Plus Jakarta Sans + Be Vietnam Pro
- Docker + serve (static hosting)
