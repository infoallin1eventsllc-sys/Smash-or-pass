import React from 'react';

export function Icon({ name, size = 24, fill = 0, className = '' }) {
  return (
    <span
      className={`material-symbols-outlined select-none ${className}`}
      style={{
        fontSize: size,
        fontVariationSettings: `'FILL' ${fill}, 'wght' 400`,
        lineHeight: 1,
      }}
    >
      {name}
    </span>
  );
}

export function Avatar({ src, alt, size = 56, online, className = '' }) {
  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <img
        src={src}
        alt={alt}
        className={`w-full h-full rounded-full object-cover ${className}`}
      />
      {online && (
        <div
          className="absolute bottom-0 right-0 bg-tertiary border-2 border-background rounded-full"
          style={{ width: size * 0.25, height: size * 0.25 }}
        />
      )}
    </div>
  );
}

export function Tag({ label }) {
  return (
    <span className="px-3 py-1 rounded-full text-xs font-semibold border border-outline/40 text-on-surface-variant bg-surface-container">
      {label}
    </span>
  );
}

export function BottomNav({ active, onNav }) {
  const items = [
    { key: 'discover', icon: 'local_fire_department' },
    { key: 'messages', icon: 'forum' },
    { key: 'profile', icon: 'person' },
  ];

  return (
    <nav className="fixed bottom-0 w-full z-50 flex justify-around items-center px-4 pb-6 pt-3 bg-surface-container-lowest/90 backdrop-blur-lg border-t border-outline-variant/20 rounded-t-2xl">
      {items.map(({ key, icon }) => {
        const isActive = active === key;
        return (
          <button
            key={key}
            onClick={() => onNav(key)}
            className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-200 active:scale-90 ${
              isActive
                ? 'text-on-primary-container bg-primary-container neon-glow-primary'
                : 'text-on-surface-variant hover:text-primary'
            }`}
          >
            <Icon name={icon} size={26} fill={isActive ? 1 : 0} />
          </button>
        );
      })}
    </nav>
  );
}

export function TopBar({ title, leftAction, rightAction }) {
  return (
    <header className="fixed top-0 w-full z-50 flex justify-between items-center px-4 py-4 bg-background/80 backdrop-blur-lg border-b border-outline-variant/10">
      <div className="w-10 flex items-center justify-start">{leftAction}</div>
      <h1 className="font-display font-black italic tracking-tighter text-2xl text-gradient-brand">
        {title}
      </h1>
      <div className="w-10 flex items-center justify-end">{rightAction}</div>
    </header>
  );
}
