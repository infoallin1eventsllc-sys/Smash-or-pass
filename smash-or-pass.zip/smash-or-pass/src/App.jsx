import React, { useState } from 'react';
import { BottomNav } from './components/UI.jsx';
import MessagesScreen from './screens/MessagesScreen.jsx';
import ChatScreen from './screens/ChatScreen.jsx';
import ProfileScreen from './screens/ProfileScreen.jsx';
import DiscoverScreen from './screens/DiscoverScreen.jsx';
import MatchScreen from './screens/MatchScreen.jsx';
import { CONVERSATIONS } from './data.js';

export default function App() {
  const [nav, setNav] = useState('discover'); // 'discover' | 'messages' | 'profile'
  const [screen, setScreen] = useState(null); // null = nav screen active
  // screen options: { type: 'chat', convId } | { type: 'profile', profileId } | { type: 'match', profile }

  const goTo = (type, payload) => setScreen({ type, ...payload });
  const goBack = () => setScreen(null);

  const handleNavChange = newNav => {
    setScreen(null);
    setNav(newNav);
  };

  // Which conversation to open after match
  const [pendingConv, setPendingConv] = useState(null);

  const handleMatch = profile => {
    // Find or pick a conversation
    const conv = CONVERSATIONS.find(c => c.userId === profile.id);
    setPendingConv(conv?.id || 'c1');
    setScreen({ type: 'match', profile });
  };

  // Render current screen
  if (screen?.type === 'match') {
    return (
      <MatchScreen
        matchedProfile={screen.profile}
        onMessage={() => {
          setNav('messages');
          setScreen({ type: 'chat', convId: pendingConv || 'c1' });
        }}
        onKeepSwiping={() => {
          setScreen(null);
          setNav('discover');
        }}
      />
    );
  }

  if (screen?.type === 'chat') {
    return (
      <ChatScreen
        convId={screen.convId}
        onBack={goBack}
        onViewProfile={profileId => goTo('profile', { profileId })}
      />
    );
  }

  if (screen?.type === 'profile') {
    return (
      <>
        <ProfileScreen
          profileId={screen.profileId}
          onBack={goBack}
          onMessage={() => {
            const conv = CONVERSATIONS.find(c => c.userId === screen.profileId);
            if (conv) {
              setNav('messages');
              goTo('chat', { convId: conv.id });
            }
          }}
          onSmash={() => handleMatch({ id: screen.profileId })}
          onPass={goBack}
        />
      </>
    );
  }

  return (
    <div className="grain-overlay">
      {/* Main nav screens */}
      <div style={{ display: nav === 'discover' ? 'block' : 'none' }}>
        <DiscoverScreen
          onMatch={handleMatch}
          onViewProfile={profileId => {
            if (profileId === null) {
              setNav('profile');
            } else {
              goTo('profile', { profileId });
            }
          }}
        />
      </div>

      <div style={{ display: nav === 'messages' ? 'block' : 'none' }}>
        <MessagesScreen
          onOpenChat={convId => goTo('chat', { convId })}
        />
      </div>

      <div style={{ display: nav === 'profile' ? 'block' : 'none' }}>
        <ProfileScreen
          profileId={null}
          onBack={() => setNav('discover')}
        />
      </div>

      <BottomNav active={nav} onNav={handleNavChange} />
    </div>
  );
}
