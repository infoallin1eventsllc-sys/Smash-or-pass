import React, { useEffect, useRef, useState } from 'react';
import { Icon } from '../components/UI.jsx';
import { CURRENT_USER } from '../data.js';

function Confetti() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const COLORS = ['#ff562c', '#ffb4a2', '#cdbdff', '#00e475', '#5203d5', '#ffffff'];
    const pieces = Array.from({ length: 100 }, () => ({
      x: Math.random() * canvas.width,
      y: -20,
      r: Math.random() * 6 + 3,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      vy: Math.random() * 3 + 2,
      vx: (Math.random() - 0.5) * 2,
      rot: Math.random() * 360,
      rotV: (Math.random() - 0.5) * 5,
      shape: Math.random() > 0.5 ? 'rect' : 'circle',
      w: Math.random() * 10 + 4,
      h: Math.random() * 5 + 3,
    }));

    let animId;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      pieces.forEach(p => {
        p.y += p.vy;
        p.x += p.vx;
        p.rot += p.rotV;
        p.vy += 0.05;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rot * Math.PI) / 180);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, 1 - p.y / canvas.height);
        if (p.shape === 'rect') {
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.r, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });
      animId = requestAnimationFrame(animate);
    };
    animate();
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-10"
      style={{ width: '100%', height: '100%' }}
    />
  );
}

export default function MatchScreen({ matchedProfile, onMessage, onKeepSwiping }) {
  const [showContent, setShowContent] = useState(false);
  const [heartBeating, setHeartBeating] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setShowContent(true), 300);
    const t2 = setTimeout(() => setHeartBeating(true), 600);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center relative overflow-hidden">
      <Confetti />

      {/* Background glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div
          className="w-96 h-96 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(255,86,44,0.15) 0%, rgba(205,189,255,0.05) 50%, transparent 70%)',
            animation: 'pulseRing 2s ease-in-out infinite',
          }}
        />
      </div>

      <div className="relative z-20 flex flex-col items-center px-6 text-center">
        {/* Title */}
        <div
          className="mb-8"
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'translateY(0)' : 'translateY(-20px)',
            transition: 'all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)',
          }}
        >
          <div className="font-display font-black text-5xl text-gradient-brand tracking-tighter leading-none mb-1">
            IT'S A
          </div>
          <div className="font-display font-black text-6xl tracking-tighter leading-none"
            style={{
              background: 'linear-gradient(135deg, #ff562c, #ffb4a2)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            MATCH!
          </div>
        </div>

        {/* Avatars */}
        <div
          className="flex items-center justify-center gap-4 mb-8"
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'scale(1)' : 'scale(0.7)',
            transition: 'all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) 0.15s',
          }}
        >
          <div className="relative">
            <img
              src={CURRENT_USER.avatar}
              alt="You"
              className="w-28 h-28 rounded-full object-cover border-4 border-primary-container"
              style={{ boxShadow: '0 0 30px rgba(255,86,44,0.5)' }}
            />
          </div>

          <div
            className={`text-5xl z-10 -mx-2 ${heartBeating ? 'animate-heart-beat' : ''}`}
            style={{ filter: 'drop-shadow(0 0 12px rgba(255,86,44,0.8))' }}
          >
            ❤️
          </div>

          <div className="relative">
            <img
              src={matchedProfile.avatar}
              alt={matchedProfile.name}
              className="w-28 h-28 rounded-full object-cover border-4 border-secondary-container"
              style={{ boxShadow: '0 0 30px rgba(82,3,213,0.5)' }}
            />
          </div>
        </div>

        {/* Message */}
        <div
          className="mb-10"
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'translateY(0)' : 'translateY(10px)',
            transition: 'all 0.5s ease 0.3s',
          }}
        >
          <p className="text-on-surface text-lg font-medium">
            You and{' '}
            <span className="font-display font-bold text-primary">{matchedProfile.name}</span>
            {' '}both swiped right!
          </p>
          <p className="text-on-surface-variant text-sm mt-1">Start a conversation now 🔥</p>
        </div>

        {/* CTA Buttons */}
        <div
          className="flex flex-col gap-3 w-full max-w-xs"
          style={{
            opacity: showContent ? 1 : 0,
            transform: showContent ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 0.5s ease 0.45s',
          }}
        >
          <button
            onClick={onMessage}
            className="w-full h-14 rounded-2xl bg-primary-container font-display font-bold text-on-primary-container text-base flex items-center justify-center gap-2 active:scale-95 transition-all"
            style={{ boxShadow: '0 0 24px rgba(255,86,44,0.5)' }}
          >
            <Icon name="chat_bubble" size={20} fill={1} />
            Send a Message
          </button>

          <button
            onClick={onKeepSwiping}
            className="w-full h-12 rounded-2xl glass-card border border-outline/20 font-display font-bold text-on-surface-variant text-sm flex items-center justify-center gap-2 active:scale-95 transition-all hover:text-on-surface"
          >
            <Icon name="local_fire_department" size={18} />
            Keep Swiping
          </button>
        </div>

        {/* Floating hearts decoration */}
        {['❤️', '🔥', '✨', '💫', '❤️'].map((emoji, i) => (
          <div
            key={i}
            className="fixed text-2xl pointer-events-none"
            style={{
              left: `${10 + i * 20}%`,
              bottom: '10%',
              animation: `floatUp ${2 + i * 0.3}s ease-out ${i * 0.4}s infinite`,
              opacity: 0,
            }}
          >
            {emoji}
          </div>
        ))}
      </div>
    </div>
  );
}
