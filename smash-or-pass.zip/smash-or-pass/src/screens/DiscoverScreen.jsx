import React, { useState, useRef, useCallback } from 'react';
import { Icon, Tag } from '../components/UI.jsx';
import { PROFILES, CURRENT_USER } from '../data.js';
import { Avatar } from '../components/UI.jsx';

const SWIPE_THRESHOLD = 80;

export default function DiscoverScreen({ onMatch, onViewProfile }) {
  const [stack, setStack] = useState([...PROFILES]);
  const [gone, setGone] = useState(new Set());
  const [dragState, setDragState] = useState({ x: 0, y: 0, dragging: false, dir: null });
  const [lastAction, setLastAction] = useState(null); // 'smash' | 'pass'
  const cardRef = useRef(null);
  const startPos = useRef(null);
  const [filterOpen, setFilterOpen] = useState(false);

  const topCard = stack[0];

  const dismiss = useCallback((dir) => {
    if (!topCard) return;
    setLastAction(dir);

    const el = cardRef.current;
    if (el) {
      const tx = dir === 'right' ? '150%' : '-150%';
      const rot = dir === 'right' ? '25deg' : '-25deg';
      el.style.transition = 'transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.4s';
      el.style.transform = `translateX(${tx}) rotate(${rot})`;
      el.style.opacity = '0';
    }

    setTimeout(() => {
      if (dir === 'right' && Math.random() > 0.4) {
        onMatch(topCard);
      }
      setStack(prev => prev.slice(1));
      setDragState({ x: 0, y: 0, dragging: false, dir: null });
      setLastAction(null);
    }, 380);
  }, [topCard, onMatch]);

  // Touch handlers
  const onTouchStart = e => {
    startPos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    setDragState(s => ({ ...s, dragging: true }));
  };

  const onTouchMove = e => {
    if (!startPos.current) return;
    const dx = e.touches[0].clientX - startPos.current.x;
    const dy = e.touches[0].clientY - startPos.current.y;
    const dir = dx > 20 ? 'right' : dx < -20 ? 'left' : null;
    setDragState({ x: dx, y: dy, dragging: true, dir });
    if (cardRef.current) {
      const rot = dx * 0.08;
      cardRef.current.style.transition = 'none';
      cardRef.current.style.transform = `translate(${dx}px, ${dy * 0.3}px) rotate(${rot}deg)`;
    }
  };

  const onTouchEnd = () => {
    if (Math.abs(dragState.x) > SWIPE_THRESHOLD) {
      dismiss(dragState.x > 0 ? 'right' : 'left');
    } else {
      if (cardRef.current) {
        cardRef.current.style.transition = 'transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)';
        cardRef.current.style.transform = 'translate(0,0) rotate(0deg)';
      }
      setDragState({ x: 0, y: 0, dragging: false, dir: null });
    }
    startPos.current = null;
  };

  // Mouse handlers for desktop
  const onMouseDown = e => {
    startPos.current = { x: e.clientX, y: e.clientY };
    setDragState(s => ({ ...s, dragging: true }));
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };
  const onMouseMove = e => {
    if (!startPos.current) return;
    const dx = e.clientX - startPos.current.x;
    const dy = e.clientY - startPos.current.y;
    const dir = dx > 20 ? 'right' : dx < -20 ? 'left' : null;
    setDragState({ x: dx, y: dy, dragging: true, dir });
    if (cardRef.current) {
      const rot = dx * 0.06;
      cardRef.current.style.transition = 'none';
      cardRef.current.style.transform = `translate(${dx}px, ${dy * 0.3}px) rotate(${rot}deg)`;
    }
  };
  const onMouseUp = () => {
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
    if (Math.abs(dragState.x) > SWIPE_THRESHOLD) {
      dismiss(dragState.x > 0 ? 'right' : 'left');
    } else {
      if (cardRef.current) {
        cardRef.current.style.transition = 'transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)';
        cardRef.current.style.transform = 'translate(0,0) rotate(0deg)';
      }
      setDragState({ x: 0, y: 0, dragging: false, dir: null });
    }
    startPos.current = null;
  };

  const swipeOpacity = Math.min(Math.abs(dragState.x) / SWIPE_THRESHOLD, 1);
  const isRight = dragState.x > 20;
  const isLeft = dragState.x < -20;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-lg px-4 pt-12 pb-3 flex justify-between items-center">
        <Avatar src={CURRENT_USER.avatar} alt="Me" size={38} onClick={() => onViewProfile(null)} className="cursor-pointer" />
        <h1 className="font-display font-black italic tracking-tighter text-2xl text-gradient-brand">SMASH OR PASS</h1>
        <button
          onClick={() => setFilterOpen(f => !f)}
          className="text-primary hover:opacity-70 active:scale-90 transition-all"
        >
          <Icon name="tune" size={24} />
        </button>
      </header>

      {/* Card stack */}
      <main className="flex-1 pt-28 pb-32 px-4 flex flex-col items-center justify-center">
        {stack.length === 0 ? (
          <div className="flex flex-col items-center gap-4 text-center animate-fade-in">
            <div className="text-6xl">🔥</div>
            <h2 className="font-display font-black text-2xl text-gradient-brand">You've seen everyone!</h2>
            <p className="text-on-surface-variant text-sm">Check back later for more matches</p>
            <button
              onClick={() => setStack([...PROFILES])}
              className="mt-2 px-6 py-3 bg-primary-container rounded-full font-display font-bold text-on-primary-container text-sm active:scale-95 transition-all"
              style={{ boxShadow: '0 0 20px rgba(255,86,44,0.4)' }}
            >
              Start over
            </button>
          </div>
        ) : (
          <div className="relative w-full max-w-sm" style={{ height: '62vh' }}>
            {/* Back cards (stack effect) */}
            {stack.slice(1, 3).map((p, i) => (
              <div
                key={p.id}
                className="absolute inset-0 rounded-3xl overflow-hidden"
                style={{
                  transform: `scale(${0.96 - i * 0.03}) translateY(${(i + 1) * 10}px)`,
                  zIndex: 10 - i,
                  transition: 'transform 0.3s ease',
                }}
              >
                <img src={p.avatar} alt={p.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
              </div>
            ))}

            {/* Top card */}
            <div
              ref={cardRef}
              className="absolute inset-0 rounded-3xl overflow-hidden z-20 cursor-grab active:cursor-grabbing animate-card-entrance"
              style={{ userSelect: 'none', touchAction: 'none' }}
              onMouseDown={onMouseDown}
              onTouchStart={onTouchStart}
              onTouchMove={onTouchMove}
              onTouchEnd={onTouchEnd}
            >
              <img
                src={topCard.avatar}
                alt={topCard.name}
                className="w-full h-full object-cover pointer-events-none"
                draggable={false}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />

              {/* SMASH badge */}
              <div
                className="absolute top-8 left-6 px-4 py-2 rounded-xl border-4 border-tertiary rotate-[-20deg] transition-opacity duration-100"
                style={{ opacity: isRight ? swipeOpacity : 0 }}
              >
                <span className="font-display font-black text-2xl text-tertiary tracking-wider">SMASH</span>
              </div>

              {/* PASS badge */}
              <div
                className="absolute top-8 right-6 px-4 py-2 rounded-xl border-4 border-error rotate-[20deg] transition-opacity duration-100"
                style={{ opacity: isLeft ? swipeOpacity : 0 }}
              >
                <span className="font-display font-black text-2xl text-error tracking-wider">PASS</span>
              </div>

              {/* Profile info */}
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <div className="flex items-end justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="font-display font-black text-3xl text-white">{topCard.name}</h2>
                      <span className="font-display font-bold text-xl text-white/70">{topCard.age}</span>
                      {topCard.verified && <Icon name="verified" size={18} className="text-secondary" fill={1} />}
                    </div>
                    <div className="flex items-center gap-1 text-white/60 text-sm mt-0.5">
                      <Icon name="location_on" size={13} />
                      <span>{topCard.distance}</span>
                    </div>
                  </div>
                  <button
                    onClick={e => { e.stopPropagation(); onViewProfile(topCard.id); }}
                    className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white active:scale-90 transition-all"
                  >
                    <Icon name="info" size={20} />
                  </button>
                </div>
                <p className="text-white/70 text-sm line-clamp-2 mb-3">{topCard.bio}</p>
                <div className="flex flex-wrap gap-1.5">
                  {topCard.tags.slice(0, 3).map(tag => (
                    <span key={tag} className="px-2.5 py-1 rounded-full bg-white/15 text-white text-xs font-medium backdrop-blur-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Action buttons */}
      {stack.length > 0 && (
        <div className="fixed bottom-20 w-full flex justify-center gap-5 px-8 z-30">
          <button
            onClick={() => dismiss('left')}
            className="w-16 h-16 rounded-full glass-card border border-error/30 flex items-center justify-center text-error hover:bg-error/10 transition-all active:scale-90"
          >
            <Icon name="close" size={28} />
          </button>

          <button
            className="w-12 h-12 rounded-full glass-card border border-secondary/30 flex items-center justify-center text-secondary self-end mb-1 hover:bg-secondary/10 transition-all active:scale-90"
          >
            <Icon name="bolt" size={22} fill={1} />
          </button>

          <button
            onClick={() => dismiss('right')}
            className="w-16 h-16 rounded-full flex items-center justify-center bg-primary-container text-on-primary-container transition-all active:scale-90"
            style={{ boxShadow: '0 0 20px rgba(255,86,44,0.5)' }}
          >
            <Icon name="favorite" size={28} fill={1} />
          </button>
        </div>
      )}
    </div>
  );
}
