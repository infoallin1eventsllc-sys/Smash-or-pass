import React, { useState } from 'react';
import { Icon, Tag } from '../components/UI.jsx';
import { PROFILES, CURRENT_USER } from '../data.js';

export default function ProfileScreen({ profileId, onBack, onMessage, onSmash, onPass }) {
  const isOwnProfile = !profileId;
  const profile = isOwnProfile
    ? { ...CURRENT_USER, age: 27, bio: 'Just a vibe-chaser with good taste 🔥 Swipe right if you can keep up.', tags: ['Music', 'Travel', 'Coffee', 'Gym'], photos: [CURRENT_USER.avatar], verified: true, online: true, distance: '0 miles' }
    : PROFILES.find(p => p.id === profileId);

  const [photoIdx, setPhotoIdx] = useState(0);
  const [smashed, setSmashed] = useState(false);
  const [passed, setPassed] = useState(false);

  if (!profile) return null;

  const photos = profile.photos || [profile.avatar];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Photo section */}
      <div className="relative w-full" style={{ height: '65vh' }}>
        <img
          src={photos[photoIdx] || profile.avatar}
          alt={profile.name}
          className="w-full h-full object-cover"
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-transparent" />

        {/* Top bar */}
        <div className="absolute top-0 left-0 right-0 flex justify-between items-center px-4 pt-12 pb-4">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-background/60 backdrop-blur-sm flex items-center justify-center text-on-surface active:scale-90 transition-all"
          >
            <Icon name="arrow_back" size={20} />
          </button>

          {!isOwnProfile && (
            <button className="w-10 h-10 rounded-full bg-background/60 backdrop-blur-sm flex items-center justify-center text-on-surface active:scale-90 transition-all">
              <Icon name="more_vert" size={20} />
            </button>
          )}
          {isOwnProfile && (
            <button className="w-10 h-10 rounded-full bg-background/60 backdrop-blur-sm flex items-center justify-center text-on-surface active:scale-90 transition-all">
              <Icon name="edit" size={20} />
            </button>
          )}
        </div>

        {/* Photo dots */}
        {photos.length > 1 && (
          <div className="absolute top-20 left-0 right-0 flex justify-center gap-1.5">
            {photos.map((_, i) => (
              <button
                key={i}
                onClick={() => setPhotoIdx(i)}
                className={`h-1 rounded-full transition-all duration-200 ${
                  i === photoIdx ? 'w-6 bg-white' : 'w-2 bg-white/40'
                }`}
              />
            ))}
          </div>
        )}

        {/* Tap zones for photo nav */}
        {photos.length > 1 && (
          <>
            <div className="absolute left-0 top-0 w-1/2 h-full" onClick={() => setPhotoIdx(i => Math.max(0, i - 1))} />
            <div className="absolute right-0 top-0 w-1/2 h-full" onClick={() => setPhotoIdx(i => Math.min(photos.length - 1, i + 1))} />
          </>
        )}

        {/* Name & info overlay */}
        <div className="absolute bottom-0 left-0 right-0 px-5 pb-4">
          <div className="flex items-end justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="font-display font-black text-3xl text-white tracking-tight">
                  {profile.name}
                </h1>
                <span className="font-display font-bold text-2xl text-white/70">{profile.age}</span>
                {profile.verified && (
                  <div className="w-5 h-5 rounded-full bg-secondary-container flex items-center justify-center">
                    <Icon name="verified" size={14} className="text-secondary" />
                  </div>
                )}
              </div>
              <div className="flex items-center gap-1 text-white/70 text-sm">
                <Icon name="location_on" size={14} />
                <span>{profile.distance} away</span>
                {profile.online && (
                  <>
                    <span className="mx-1">·</span>
                    <span className="text-tertiary font-medium">Active now</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Info section */}
      <div className="flex-1 px-5 pt-4 pb-32 flex flex-col gap-5">
        {/* Bio */}
        <div>
          <p className="text-on-surface leading-relaxed">{profile.bio}</p>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {profile.tags?.map(tag => <Tag key={tag} label={tag} />)}
        </div>

        {/* Stats (own profile) */}
        {isOwnProfile && (
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Matches', value: '47' },
              { label: 'Smashes', value: '128' },
              { label: 'Pass Rate', value: '62%' },
            ].map(({ label, value }) => (
              <div key={label} className="glass-card rounded-xl p-3 text-center">
                <div className="font-display font-black text-xl text-gradient-brand">{value}</div>
                <div className="text-xs text-on-surface-variant mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Divider */}
        <div className="h-px bg-outline-variant/20" />

        {/* Details */}
        <div className="flex flex-col gap-3">
          {[
            { icon: 'school', label: 'University of Arts' },
            { icon: 'work', label: isOwnProfile ? 'Product Designer' : profile.tags?.[0] + ' enthusiast' },
            { icon: 'favorite', label: 'Looking for something real' },
          ].map(({ icon, label }) => (
            <div key={icon} className="flex items-center gap-3 text-on-surface-variant">
              <Icon name={icon} size={18} className="text-primary/70" />
              <span className="text-sm">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Action buttons */}
      {!isOwnProfile && (
        <div className="fixed bottom-0 w-full z-50 px-5 pb-8 pt-4 bg-gradient-to-t from-background via-background/95 to-transparent">
          <div className="flex gap-3 items-center">
            <button
              onClick={() => { setPassed(true); onPass?.(); }}
              className={`flex-1 h-14 rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 ${
                passed
                  ? 'bg-outline/30 text-on-surface-variant'
                  : 'glass-card border border-outline/30 text-on-surface hover:border-error/50'
              }`}
            >
              <span className="text-lg">👎</span>
              PASS
            </button>

            <button
              onClick={() => onMessage?.()}
              className="w-12 h-12 rounded-full glass-card border border-outline/20 flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors active:scale-90"
            >
              <Icon name="chat_bubble" size={20} />
            </button>

            <button
              onClick={() => { setSmashed(true); onSmash?.(); }}
              className={`flex-1 h-14 rounded-2xl font-display font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 ${
                smashed
                  ? 'bg-primary-container/50 text-primary'
                  : 'bg-primary-container text-on-primary-container'
              }`}
              style={!smashed ? { boxShadow: '0 0 20px rgba(255,86,44,0.4)' } : {}}
            >
              <span className="text-lg">🔥</span>
              SMASH
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
