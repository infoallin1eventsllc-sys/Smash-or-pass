import React, { useState, useRef, useEffect } from 'react';
import { Icon, Avatar } from '../components/UI.jsx';
import { PROFILES, CONVERSATIONS, CURRENT_USER } from '../data.js';

export default function ChatScreen({ convId, onBack, onViewProfile }) {
  const conv = CONVERSATIONS.find(c => c.id === convId);
  const profile = PROFILES.find(p => p.id === conv?.userId);
  const [messages, setMessages] = useState(conv?.messages || []);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showReaction, setShowReaction] = useState(null);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Simulate the other person typing after you send
  const sendMessage = () => {
    if (!input.trim()) return;
    const newMsg = {
      id: `m${Date.now()}`,
      from: 'me',
      text: input.trim(),
      time: 'Just now',
      read: true,
    };
    setMessages(prev => [...prev, newMsg]);
    setInput('');

    // Simulate typing response
    setTimeout(() => setIsTyping(true), 800);
    setTimeout(() => {
      setIsTyping(false);
      const responses = [
        'That\'s actually so funny 😂',
        'Omg yes!! 🔥',
        'Wait really?? Tell me more',
        '100% same vibes fr',
        'Ok you\'re kind of amazing ngl',
      ];
      setMessages(prev => [...prev, {
        id: `m${Date.now()}`,
        from: profile.id,
        text: responses[Math.floor(Math.random() * responses.length)],
        time: 'Just now',
        read: false,
      }]);
    }, 2800);
  };

  const handleKeyDown = e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleReaction = (msgId, emoji) => {
    setShowReaction({ msgId, emoji });
    setTimeout(() => setShowReaction(null), 1500);
  };

  if (!conv || !profile) return null;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-background/90 backdrop-blur-lg border-b border-outline-variant/10 px-4 pt-10 pb-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="text-on-surface-variant hover:text-primary transition-colors active:scale-90 p-1"
          >
            <Icon name="arrow_back" size={24} />
          </button>

          <button
            onClick={() => onViewProfile(profile.id)}
            className="flex items-center gap-3 flex-1 active:opacity-70"
          >
            <Avatar src={profile.avatar} alt={profile.name} size={44} online={profile.online} />
            <div className="flex-1 text-left">
              <div className="font-display font-bold text-sm text-on-surface">{profile.name}, {profile.age}</div>
              <div className={`text-xs ${profile.online ? 'text-tertiary' : 'text-on-surface-variant'}`}>
                {profile.online ? '● Active now' : 'Last seen recently'}
              </div>
            </div>
          </button>

          <div className="flex gap-1">
            <button className="text-on-surface-variant hover:text-primary transition-colors active:scale-90 p-2">
              <Icon name="videocam" size={22} />
            </button>
            <button className="text-on-surface-variant hover:text-primary transition-colors active:scale-90 p-2">
              <Icon name="more_vert" size={22} />
            </button>
          </div>
        </div>
      </header>

      {/* Messages */}
      <main className="flex-1 pt-28 pb-24 px-4 overflow-y-auto no-scrollbar">
        {/* Match banner */}
        <div className="text-center mb-6 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-surface-container border border-outline-variant/30">
            <span className="text-primary">❤️</span>
            <span className="text-xs text-on-surface-variant font-medium">You matched with {profile.name}!</span>
            <span className="text-primary">❤️</span>
          </div>
          <div className="mt-2 text-[10px] text-on-surface-variant/50">March 15, 2025</div>
        </div>

        <div className="flex flex-col gap-3">
          {messages.map((msg, i) => {
            const isMe = msg.from === 'me';
            const showAvatar = !isMe && (i === 0 || messages[i - 1].from === 'me');

            return (
              <div
                key={msg.id}
                className={`flex items-end gap-2 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
                style={{ animation: `slideUp 0.3s ease-out both` }}
              >
                {!isMe && (
                  <div style={{ width: 32, flexShrink: 0 }}>
                    {showAvatar && (
                      <img src={profile.avatar} alt="" className="w-8 h-8 rounded-full object-cover" />
                    )}
                  </div>
                )}

                <div className={`group relative max-w-[72%]`}>
                  <div
                    className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed cursor-pointer transition-transform active:scale-95 ${
                      isMe
                        ? 'bg-primary-container text-white rounded-br-sm'
                        : 'bg-surface-container-high text-on-surface rounded-bl-sm'
                    }`}
                    onDoubleClick={() => handleReaction(msg.id, '❤️')}
                  >
                    {msg.text}
                  </div>

                  {/* Reaction popup */}
                  {showReaction?.msgId === msg.id && (
                    <div
                      className="absolute -top-8 left-1/2 -translate-x-1/2 text-xl animate-scale-in"
                      style={{ animation: 'floatUp 1.5s ease-out forwards' }}
                    >
                      {showReaction.emoji}
                    </div>
                  )}

                  <div className={`text-[10px] text-on-surface-variant mt-1 ${isMe ? 'text-right' : 'text-left'}`}>
                    {msg.time}
                    {isMe && <span className="ml-1 text-tertiary">✓✓</span>}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Typing indicator */}
          {isTyping && (
            <div className="flex items-end gap-2">
              <img src={profile.avatar} alt="" className="w-8 h-8 rounded-full object-cover flex-shrink-0" />
              <div className="bg-surface-container-high px-4 py-3 rounded-2xl rounded-bl-sm flex gap-1.5 items-center">
                {[0, 1, 2].map(i => (
                  <div
                    key={i}
                    className="w-2 h-2 bg-on-surface-variant rounded-full typing-dot"
                    style={{ animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </main>

      {/* Input */}
      <div className="fixed bottom-0 w-full z-50 px-4 pb-6 pt-3 bg-background/90 backdrop-blur-lg border-t border-outline-variant/10">
        <div className="flex items-center gap-2">
          <button className="text-on-surface-variant hover:text-primary transition-colors active:scale-90 p-2 flex-shrink-0">
            <Icon name="add_circle" size={24} />
          </button>

          <div className="flex-1 flex items-center bg-surface-container rounded-full px-4 py-2.5 gap-2">
            <input
              ref={inputRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Message..."
              className="flex-1 bg-transparent text-on-surface text-sm outline-none placeholder-on-surface-variant/50"
            />
            <button className="text-on-surface-variant hover:text-primary transition-colors active:scale-90">
              <Icon name="sentiment_satisfied" size={20} />
            </button>
          </div>

          <button
            onClick={sendMessage}
            disabled={!input.trim()}
            className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all active:scale-90 ${
              input.trim()
                ? 'bg-primary-container text-on-primary-container'
                : 'bg-surface-container text-on-surface-variant'
            }`}
            style={input.trim() ? { boxShadow: '0 0 12px rgba(255,86,44,0.5)' } : {}}
          >
            <Icon name="send" size={18} fill={input.trim() ? 1 : 0} />
          </button>
        </div>
      </div>
    </div>
  );
}
