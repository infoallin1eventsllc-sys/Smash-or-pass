import React, { useState } from 'react';
import { Icon, Avatar } from '../components/UI.jsx';
import { PROFILES, CONVERSATIONS, CURRENT_USER } from '../data.js';

function getProfile(userId) {
  return PROFILES.find(p => p.id === userId);
}

function getLastMessage(conv) {
  return conv.messages[conv.messages.length - 1];
}

function hasUnread(conv) {
  return conv.messages.some(m => m.from !== 'me' && !m.read);
}

export default function MessagesScreen({ onOpenChat }) {
  const [tab, setTab] = useState('messages');

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-background/90 backdrop-blur-lg border-b border-outline-variant/10 px-4 pt-12 pb-0">
        <div className="flex justify-between items-center mb-4">
          <Avatar src={CURRENT_USER.avatar} alt="Me" size={40} />
          <h1 className="font-display font-black italic tracking-tighter text-2xl text-gradient-brand">
            SMASH OR PASS
          </h1>
          <button className="text-primary hover:opacity-70 transition-opacity active:scale-90">
            <Icon name="tune" size={26} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-outline-variant/20">
          {['messages', 'groups'].map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`pb-3 px-4 text-sm font-bold font-display capitalize transition-all duration-200 relative ${
                tab === t ? 'text-primary' : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              {t === 'messages' ? 'Messages' : 'Group Chats'}
              {tab === t && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-container rounded-full"
                  style={{ boxShadow: '0 0 8px rgba(255,86,44,0.6)' }} />
              )}
            </button>
          ))}
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 pt-36 pb-24 px-4">
        {tab === 'messages' ? (
          <div className="flex flex-col gap-2">
            {CONVERSATIONS.map((conv, i) => {
              const profile = getProfile(conv.userId);
              const last = getLastMessage(conv);
              const unread = hasUnread(conv);
              const isFromMe = last.from === 'me';

              return (
                <button
                  key={conv.id}
                  onClick={() => onOpenChat(conv.id)}
                  className="glass-card rounded-2xl p-4 flex items-center gap-4 hover:bg-surface-container-high transition-all duration-200 active:scale-[0.98] text-left w-full group"
                  style={{
                    animation: `slideUp 0.4s ease-out ${i * 0.07}s both`,
                  }}
                >
                  <Avatar
                    src={profile.avatar}
                    alt={profile.name}
                    size={60}
                    online={profile.online}
                    className={!unread ? 'grayscale group-hover:grayscale-0 transition-all duration-300' : ''}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline mb-1">
                      <span className={`font-display font-bold text-sm ${unread ? 'text-on-surface' : 'text-on-surface-variant group-hover:text-on-surface'}`}>
                        {profile.name}, {profile.age}
                      </span>
                      <span className={`text-[10px] font-bold ${unread ? 'text-primary' : 'text-on-surface-variant'}`}>
                        {last.time}
                      </span>
                    </div>
                    <p className={`text-sm truncate ${unread ? 'text-on-surface font-semibold' : 'text-on-surface-variant'}`}>
                      {isFromMe ? `You: ${last.text}` : last.text}
                    </p>
                  </div>
                  {unread && (
                    <div className="w-3 h-3 bg-primary-container rounded-full flex-shrink-0"
                      style={{ boxShadow: '0 0 10px rgba(255,86,44,0.8)' }} />
                  )}
                </button>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {[
              { name: 'Main Squad 🚀', last: 'Leo: Did anyone see Sarah\'s profile? SMASH.', time: 'Active', unread: 3, color: 'text-tertiary' },
              { name: 'The Roast Panel', last: 'Jen: That bio was a total pass lol...', time: '2h ago', unread: 0, color: 'text-on-surface-variant' },
            ].map((group, i) => (
              <div
                key={i}
                className="glass-card rounded-2xl p-4 flex items-center gap-4 hover:bg-surface-container-high transition-all duration-200 cursor-pointer active:scale-[0.98]"
                style={{ animation: `slideUp 0.4s ease-out ${i * 0.1}s both` }}
              >
                <div className="relative w-14 h-14 flex-shrink-0">
                  <img src={PROFILES[0].avatar} alt="" className="absolute top-0 left-0 w-9 h-9 rounded-full object-cover border-2 border-background z-10" />
                  <img src={PROFILES[2].avatar} alt="" className="absolute bottom-0 right-0 w-9 h-9 rounded-full object-cover border-2 border-background" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-display font-bold text-sm text-on-surface">{group.name}</span>
                    <span className={`text-[10px] font-bold ${group.color}`}>{group.time}</span>
                  </div>
                  <p className={`text-sm truncate ${group.unread ? 'text-on-surface font-semibold' : 'text-on-surface-variant'}`}>
                    {group.last}
                  </p>
                </div>
                {group.unread > 0 && (
                  <div className="px-2 py-0.5 bg-secondary-container rounded-full text-white text-[10px] font-bold flex-shrink-0">
                    {group.unread}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* FAB */}
      <button
        className="fixed bottom-24 right-4 w-14 h-14 bg-primary-container rounded-full flex items-center justify-center text-on-primary-container active:scale-90 transition-all z-40"
        style={{ boxShadow: '0 0 24px rgba(255,86,44,0.6)' }}
      >
        <Icon name="edit_square" size={26} />
      </button>
    </div>
  );
}
