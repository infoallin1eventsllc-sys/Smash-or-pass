// Mock data for the entire app

export const CURRENT_USER = {
  id: 'me',
  name: 'Alex',
  age: 27,
  avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBuLewYTM7VDdYnArf1aIdBJogY-bS59GwDtUZ8YnXa93ARzfhNhRFMbLeULc4HUXmG9NhH1cnKV_WXA9028SwFJogd9PhESkLtPuvqP210ta3InaZF_9h37xdndD0Y5G3FsALuyMTNzXgdrkkVRLGlwMTZ38kDGVifXOleyNuA4enTGIrc8LhMbEhbmmxpzJtgQ8zHUucp40nV2c1cfFHReFO_7jpVOgjz7T69V69scPBt_WH4ip1a0XWLAmCyFCT2OGxxNHSA5IA',
};

export const PROFILES = [
  {
    id: '1',
    name: 'Sarah',
    age: 24,
    distance: '2 miles',
    bio: 'Concert-goer 🎶 Dog mom 🐾 Coffee addict ☕ Looking for someone to explore the city with.',
    tags: ['Music', 'Dogs', 'Coffee', 'Art'],
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAPyHWHalb8hx4yldehzBZ4zN7N-vS545C71hj9oi5OCoepa9VJGPsCwLFAQ9DcW4IFYLJTtCMwymO3tXbNSnk1-YFgoAHi6QIxvKFHqQLdCvHMstlR1km5C4ob7tAmB9FYZvGUGjdZL3GZZlKXvv-D65EzJHjc93uo1W1-HkLhD0WkDTMt4cdrSXpXOaA27coM5H7C7eP5d3GwZP4-i0OQMxnGNY1usgmMl2VXOMpnPdWhPpHBMtbnyjPdog_iSRcwycw1SN16zUA',
    photos: [
      'https://lh3.googleusercontent.com/aida-public/AB6AXuAPyHWHalb8hx4yldehzBZ4zN7N-vS545C71hj9oi5OCoepa9VJGPsCwLFAQ9DcW4IFYLJTtCMwymO3tXbNSnk1-YFgoAHi6QIxvKFHqQLdCvHMstlR1km5C4ob7tAmB9FYZvGUGjdZL3GZZlKXvv-D65EzJHjc93uo1W1-HkLhD0WkDTMt4cdrSXpXOaA27coM5H7C7eP5d3GwZP4-i0OQMxnGNY1usgmMl2VXOMpnPdWhPpHBMtbnyjPdog_iSRcwycw1SN16zUA',
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBghpQVgVjbJqcf4lw5J-eVzWNsZnEJRxGelcJv2WN_GCr389g5fUORky1OPP34FwribXtDxmDd1s2rtzVR9Tn-L9rxXmng2fcuG9NwY9QHY-gJKW82C4fQole_JFVaduiBs7_PmB1U23R_6g9VteF68T8YPla5hBoReMzOyFXEZFp_yzc6Luk8Owta6actvVuJT_Q00HjXKTtlbiaYVa-1Hye4baxNRMBrVX8pjwanB-x2SE9TiKyJNVzPvdbAx16YQWqw-aJbVGg',
    ],
    online: true,
    verified: true,
  },
  {
    id: '2',
    name: 'Chloe',
    age: 22,
    distance: '5 miles',
    bio: 'Film student & aspiring director 🎬 Into indie films, bad puns, and good ramen. Swipe right if you can keep up.',
    tags: ['Film', 'Ramen', 'Travel', 'Memes'],
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDsPTOXxTsFuSLul4bw5J4SUOGYVOCj5IJnyz1BIC5XLUkjdtmOK7U_1ASB_UDrneqzWrwOO8h6rE_whlytQvyM0zpAvARmv1p4wKqsihdLCsXQuqN9fZzbBYAQyVVwpXRFeJ55nVnZcE91k8hYqJ7Fu9w2vPg5ZrqA6NPzRcrXAhS--omz_u4Koi_8RDUnhJdxpZ_ZkYAYecabv7xCQWLATnEEgf742uWGhFAhvvLjrz3jlfHtWN2h7kT2RwprNdKGjTGJzW13Slc',
    photos: [
      'https://lh3.googleusercontent.com/aida-public/AB6AXuDsPTOXxTsFuSLul4bw5J4SUOGYVOCj5IJnyz1BIC5XLUkjdtmOK7U_1ASB_UDrneqzWrwOO8h6rE_whlytQvyM0zpAvARmv1p4wKqsihdLCsXQuqN9fZzbBYAQyVVwpXRFeJ55nVnZcE91k8hYqJ7Fu9w2vPg5ZrqA6NPzRcrXAhS--omz_u4Koi_8RDUnhJdxpZ_ZkYAYecabv7xCQWLATnEEgf742uWGhFAhvvLjrz3jlfHtWN2h7kT2RwprNdKGjTGJzW13Slc',
    ],
    online: false,
    verified: false,
  },
  {
    id: '3',
    name: 'Marcus',
    age: 26,
    distance: '1 mile',
    bio: 'Startup founder by day, DJ by night 🎧 Big into fitness, philosophy, and finding the best tacos in the city.',
    tags: ['Tech', 'Music', 'Fitness', 'Tacos'],
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBdT2I5WSwIayg0Y4ikTzM2CMHsIjAVhB8wMXaMC9qgNoae67RmJFj0xhgPJ0ZhuZA7LDAI4ccpf_BgLvZsVhvCzthTnKj079rkLiq1mwjHKCBpdaT-9xqcjN2cFPrSVsJgG-oq4lWntrNWbFFn85LNvJYTscDuBgafP-Q5S5m7UOn09QMRtJSbjpFCgscOWaqsbz6uEmCawH9LpsCMeAqprRTcmnWF-URmMXP8vfWLj0_ngkXLYXRPVYdw2JXDOPoVmSX2fNm8Pc0',
    photos: [
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBdT2I5WSwIayg0Y4ikTzM2CMHsIjAVhB8wMXaMC9qgNoae67RmJFj0xhgPJ0ZhuZA7LDAI4ccpf_BgLvZsVhvCzthTnKj079rkLiq1mwjHKCBpdaT-9xqcjN2cFPrSVsJgG-oq4lWntrNWbFFn85LNvJYTscDuBgafP-Q5S5m7UOn09QMRtJSbjpFCgscOWaqsbz6uEmCawH9LpsCMeAqprRTcmnWF-URmMXP8vfWLj0_ngkXLYXRPVYdw2JXDOPoVmSX2fNm8Pc0',
    ],
    online: true,
    verified: true,
  },
  {
    id: '4',
    name: 'Elena',
    age: 25,
    distance: '8 miles',
    bio: 'Architect of spaces and vibes 🏛️ Into design, jazz, and slow Sunday mornings. Let\'s build something.',
    tags: ['Design', 'Jazz', 'Architecture', 'Travel'],
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBIj1TngZLt68IVb6gS123x8gryT-UoLCywmOv6wFm-EqiwXEnTZ6bJH88KUFOUBQKZy9FK5ozjbAwj7AK1pMpg1IutOg-DSU9-y8mog4kbYAv1gBVL6TkXV6ry9LRY_lU-yYY4JaIRsGEhOjau6gDbp1JLibj-ezv3Vou6CA0Uz1sNhzynB8Q_08GMcjnYxVwptybF304B90uC9wNAVrplPw-iM2HM9zL_c6ChJIAR3_grqnzpgmpb7S5kJvKJmDv7PxXFjraVbG4',
    photos: [
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBIj1TngZLt68IVb6gS123x8gryT-UoLCywmOv6wFm-EqiwXEnTZ6bJH88KUFOUBQKZy9FK5ozjbAwj7AK1pMpg1IutOg-DSU9-y8mog4kbYAv1gBVL6TkXV6ry9LRY_lU-yYY4JaIRsGEhOjau6gDbp1JLibj-ezv3Vou6CA0Uz1sNhzynB8Q_08GMcjnYxVwptybF304B90uC9wNAVrplPw-iM2HM9zL_c6ChJIAR3_grqnzpgmpb7S5kJvKJmDv7PxXFjraVbG4',
    ],
    online: false,
    verified: true,
  },
  {
    id: '5',
    name: 'Jordan',
    age: 28,
    distance: '3 miles',
    bio: 'Chef & food photographer 📸🍜 If you can appreciate a perfectly plated dish, we\'ll get along just fine.',
    tags: ['Food', 'Photography', 'Travel', 'Wine'],
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBWaziolJu8oSI6tH7_Kl2cAts5AfU6ZTW2dRh0YbmNTn1vlEzMdscNp5E4IzXqwpZVC9KdgYVt_5Li-Z6A4OU-48fy-0fPzmPUSzei_JccGGrUu7MWb3yMunIZWw_zGXaJ_MrKoPCl1NLzMwbZQ3qnV5LSiYF5y5Jl7_6RR3hA6v_b2bmFmN5LKScid5Pcb39jcvNKx7muSAT0-l2-AYHP10eJn7Q57Lje2BmW0hKntDPQArGjeq0Qs9NsAccjIESxj-DVMq_jCS4',
    photos: [
      'https://lh3.googleusercontent.com/aida-public/AB6AXuBWaziolJu8oSI6tH7_Kl2cAts5AfU6ZTW2dRh0YbmNTn1vlEzMdscNp5E4IzXqwpZVC9KdgYVt_5Li-Z6A4OU-48fy-0fPzmPUSzei_JccGGrUu7MWb3yMunIZWw_zGXaJ_MrKoPCl1NLzMwbZQ3qnV5LSiYF5y5Jl7_6RR3hA6v_b2bmFmN5LKScid5Pcb39jcvNKx7muSAT0-l2-AYHP10eJn7Q57Lje2BmW0hKntDPQArGjeq0Qs9NsAccjIESxj-DVMq_jCS4',
    ],
    online: true,
    verified: false,
  },
];

export const CONVERSATIONS = [
  {
    id: 'c1',
    userId: '1',
    messages: [
      { id: 'm1', from: '1', text: 'Hey! I love your profile 😍', time: '2:01 PM', read: true },
      { id: 'm2', from: 'me', text: 'Thanks! Yours is amazing too 🔥', time: '2:03 PM', read: true },
      { id: 'm3', from: '1', text: 'We should grab coffee sometime?', time: '2:05 PM', read: true },
      { id: 'm4', from: 'me', text: 'Absolutely! I know a great spot downtown', time: '2:06 PM', read: true },
      { id: 'm5', from: '1', text: 'Are we still on for the concert tonight? 🔥', time: '2 min ago', read: false },
    ],
  },
  {
    id: 'c2',
    userId: '2',
    messages: [
      { id: 'm1', from: '2', text: 'That dog in your profile is so cute!', time: '1h ago', read: true },
    ],
  },
  {
    id: 'c3',
    userId: '3',
    messages: [
      { id: 'm1', from: 'me', text: 'Hey Marcus, want to check out that new spot Friday?', time: 'Yesterday', read: true },
      { id: 'm2', from: '3', text: 'Definitely. I\'ll send the location.', time: 'Yesterday', read: true },
    ],
  },
  {
    id: 'c4',
    userId: '4',
    messages: [
      { id: 'm1', from: '4', text: 'Your taste in architecture is actually impressive', time: '2d ago', read: true },
      { id: 'm2', from: 'me', text: 'Ha, I try. Brutalism is underrated', time: '2d ago', read: true },
      { id: 'm3', from: '4', text: 'Haha, that\'s actually a great point...', time: '2d ago', read: true },
    ],
  },
];
