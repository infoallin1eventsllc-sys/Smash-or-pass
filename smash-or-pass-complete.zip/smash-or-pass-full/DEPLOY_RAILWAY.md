# Deploy to Railway

Railway is the easiest option for this full-stack app.

## Setup (5 minutes)

1. **Create Railway account**: https://railway.app

2. **Connect GitHub**:
   - Go to Dashboard → Connect GitHub
   - Authorize Railway

3. **Create project**: New Project → Deploy from GitHub

4. **Select this repo** and main branch

5. **Add services**:
   - Click "Add Service" → GitHub Repo
   - Select this repo (it auto-detects services)

6. **Configure MongoDB**:
   - Add → Database → MongoDB
   - Railway auto-creates and connects

7. **Set environment variables**:
   
   Backend (.env):
   ```
   JWT_SECRET=your-secure-random-string
   FRONTEND_URL=https://your-frontend.railway.app
   NODE_ENV=production
   ```
   
   Frontend (.env):
   ```
   VITE_API_URL=https://your-backend.railway.app/api
   VITE_WS_URL=https://your-backend.railway.app
   ```

8. **Deploy**:
   - Railway auto-deploys on push to main
   - Watch build logs in Dashboard

## URLs
- Frontend: `https://[project]-frontend.railway.app`
- Backend: `https://[project]-backend.railway.app`
- WebSocket: Same as backend (wss://)

## Monitor
- Real-time logs in Railway dashboard
- Automatic rollback on failed deploys
- Free tier includes 500 hours/month
