# Deploy to AWS (ECS + ALB)

Production-grade deployment with auto-scaling, CDN, and database backups.

## Prerequisites
- AWS Account (free tier eligible)
- AWS CLI installed and configured
- Docker images pushed to ECR

## Architecture
```
Route 53 (DNS)
    ↓
CloudFront (CDN)
    ↓
ALB (Load Balancer)
    ├→ ECS Frontend (port 3000)
    ├→ ECS Backend (port 5000)
    └→ RDS PostgreSQL
```

## Step 1: Create ECR Repositories

```bash
aws ecr create-repository --repository-name smash-or-pass-frontend
aws ecr create-repository --repository-name smash-or-pass-backend
aws ecr create-repository --repository-name smash-or-pass-mongodb
```

## Step 2: Build & Push Images

```bash
# Login to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_AWS_ID.dkr.ecr.us-east-1.amazonaws.com

# Frontend
docker build -t smash-or-pass-frontend ./frontend
docker tag smash-or-pass-frontend:latest YOUR_AWS_ID.dkr.ecr.us-east-1.amazonaws.com/smash-or-pass-frontend:latest
docker push YOUR_AWS_ID.dkr.ecr.us-east-1.amazonaws.com/smash-or-pass-frontend:latest

# Backend
docker build -t smash-or-pass-backend ./backend
docker tag smash-or-pass-backend:latest YOUR_AWS_ID.dkr.ecr.us-east-1.amazonaws.com/smash-or-pass-backend:latest
docker push YOUR_AWS_ID.dkr.ecr.us-east-1.amazonaws.com/smash-or-pass-backend:latest
```

## Step 3: RDS Database

1. **AWS Console** → RDS → Create Database
   - Engine: MongoDB (DocumentDB) or PostgreSQL
   - Instance: db.t4g.medium (free tier eligible)
   - Storage: 20GB, SSD
   - Backup retention: 7 days
   - Multi-AZ: Enabled

2. **Save connection string** → Backend environment variables

## Step 4: ECS Cluster

```bash
aws ecs create-cluster --cluster-name smash-or-pass
```

## Step 5: Create Task Definitions

Create `backend-task.json`:
```json
{
  "family": "smash-or-pass-backend",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "containerDefinitions": [{
    "name": "backend",
    "image": "YOUR_AWS_ID.dkr.ecr.us-east-1.amazonaws.com/smash-or-pass-backend:latest",
    "portMappings": [{"containerPort": 5000}],
    "environment": [
      {"name": "MONGODB_URI", "value": "YOUR_MONGODB_URI"},
      {"name": "JWT_SECRET", "value": "YOUR_JWT_SECRET"},
      {"name": "NODE_ENV", "value": "production"}
    ],
    "logConfiguration": {
      "logDriver": "awslogs",
      "options": {
        "awslogs-group": "/ecs/smash-or-pass-backend",
        "awslogs-region": "us-east-1",
        "awslogs-stream-prefix": "ecs"
      }
    }
  }]
}
```

Register task:
```bash
aws ecs register-task-definition --cli-input-json file://backend-task.json
```

## Step 6: Create Services

```bash
aws ecs create-service \
  --cluster smash-or-pass \
  --service-name backend \
  --task-definition smash-or-pass-backend \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx,subnet-yyy],securityGroups=[sg-xxx]}"
```

Repeat for frontend.

## Step 7: Application Load Balancer

1. **Create ALB** in EC2 → Load Balancers
2. **Target Groups**:
   - frontend:3000
   - backend:5000
3. **Listener Rules**:
   - `/api/*` → backend target group
   - `/*` → frontend target group

## Step 8: CloudFront CDN

1. Create distribution pointing to ALB
2. Cache frontend assets indefinitely
3. Forward `/api` requests without caching

## Step 9: Route 53 DNS

1. Create hosted zone
2. Create A record → CloudFront distribution
3. Enable HTTPS (ACM certificate)

## Step 10: Auto-Scaling

```bash
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/smash-or-pass/backend \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 \
  --max-capacity 10

aws application-autoscaling put-scaling-policy \
  --policy-name cpu-scaling \
  --service-namespace ecs \
  --resource-id service/smash-or-pass/backend \
  --scalable-dimension ecs:service:DesiredCount \
  --policy-type TargetTrackingScaling \
  --target-tracking-scaling-policy-configuration "TargetValue=70.0,PredefinedMetricSpecification={PredefinedMetricType=ECSServiceAverageCPUUtilization}"
```

## Monitoring

- CloudWatch: Real-time metrics & logs
- X-Ray: Distributed tracing
- SNS: Alerts on failures

## Cost (Approximate)
- ECS Fargate: ~$50/month
- RDS: ~$30/month
- ALB: ~$16/month
- CloudFront: ~$5/month
- **Total: ~$100/month**

Free tier covers first 750 hours/month of EC2 + first 20GB bandwidth.
