import React, { useState, useEffect } from 'react';
import { BottomNav } from './components/UI.jsx';
import AuthScreen from './screens/AuthScreen.jsx';
import MessagesScreen from './screens/MessagesScreen.jsx';
import ChatScreen from './screens/ChatScreen.jsx';
import ProfileScreen from './screens/ProfileScreen.jsx';
import DiscoverScreen from './screens/DiscoverScreen.jsx';
import MatchScreen from './screens/MatchScreen.jsx';
import { CONVERSATIONS, PROFILES } from './data.js';
import { initSocket, getSocket, getConversations } from './api.js';

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [nav, setNav] = useState('discover');
  const [screen, setScreen] = useState(null);
  const [pendingConv, setPendingConv] = useState(null);
  const [conversations, setConversations] = useState([]);

  // Check if user is logged in
  useEffect(() => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    if (token && userId) {
      setUser({ id: userId });
      initSocket(userId);
    }
    setLoading(false);
  }, []);

  // Listen for WebSocket events
  useEffect(() => {
    if (!user) return;
    const sock = getSocket();
    if (!sock) return;

    sock.on('match:new', (data) => {
      const profile = PROFILES.find(p => p.id === data.matchedWith);
      if (profile) handleMatch(profile);
    });

    sock.on('message:new', () => loadConversations());

    return () => {
      sock.off('match:new');
      sock.off('message:new');
    };
  }, [user]);

  const loadConversations = async () => {
    try {
      const res = await getConversations();
      if (res.data) setConversations(res.data);
    } catch (err) {
      console.error('Failed to load conversations:', err);
    }
  };

  const goTo = (type, payload) => setScreen({ type, ...payload });
  const goBack = () => setScreen(null);
  const handleNavChange = newNav => {
    setScreen(null);
    setNav(newNav);
  };

  const handleMatch = profile => {
    setPendingConv('c1');
    setScreen({ type: 'match', profile });
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    setUser(null);
    setNav('discover');
    setScreen(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-on-surface-variant">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen onAuthSuccess={(userData) => {
      setUser(userData);
      initSocket(userData.id);
      loadConversations();
    }} />;
  }

  // Render current screen
  if (screen?.type === 'match') {
    return (
      <MatchScreen
        matchedProfile={screen.profile}
        onMessage={() => {
          setNav('messages');
          setScreen({ type: 'chat', convId: pendingConv || 'c1' });
        }}
        onKeepSwiping={() => {
          setScreen(null);
          setNav('discover');
        }}
      />
    );
  }

  if (screen?.type === 'chat') {
    return (
      <ChatScreen
        convId={screen.convId}
        onBack={goBack}
        onViewProfile={profileId => goTo('profile', { profileId })}
      />
    );
  }

  if (screen?.type === 'profile') {
    return (
      <>
        <ProfileScreen
          profileId={screen.profileId}
          onBack={goBack}
          onMessage={() => {
            const conv = CONVERSATIONS.find(c => c.userId === screen.profileId);
            if (conv) {
              setNav('messages');
              goTo('chat', { convId: conv.id });
            }
          }}
          onSmash={() => handleMatch({ id: screen.profileId })}
          onPass={goBack}
        />
      </>
    );
  }

  return (
    <div className="grain-overlay">
      {/* Main nav screens */}
      <div style={{ display: nav === 'discover' ? 'block' : 'none' }}>
        <DiscoverScreen
          onMatch={handleMatch}
          onViewProfile={profileId => {
            if (profileId === null) {
              setNav('profile');
            } else {
              goTo('profile', { profileId });
            }
          }}
        />
      </div>

  if (screen?.type === 'match') {
    return (
      <MatchScreen
        matchedProfile={screen.profile}
        onMessage={() => {
          setNav('messages');
          setScreen({ type: 'chat', convId: pendingConv || 'c1' });
        }}
        onKeepSwiping={() => {
          setScreen(null);
          setNav('discover');
        }}
      />
    );
  }

  if (screen?.type === 'chat') {
    return (
      <ChatScreen
        convId={screen.convId}
        onBack={goBack}
        onViewProfile={profileId => goTo('profile', { profileId })}
        socket={getSocket()}
      />
    );
  }

  if (screen?.type === 'profile') {
    return (
      <ProfileScreen
        profileId={screen.profileId}
        onBack={goBack}
        onMessage={() => {
          const conv = conversations.find(c => c.userId === screen.profileId);
          if (conv) {
            setNav('messages');
            goTo('chat', { convId: conv.id });
          }
        }}
        onSmash={() => handleMatch({ id: screen.profileId })}
        onPass={goBack}
      />
    );
  }

  return (
    <div className="grain-overlay">
      <div style={{ display: nav === 'discover' ? 'block' : 'none' }}>
        <DiscoverScreen
          onMatch={handleMatch}
          onViewProfile={profileId => {
            if (profileId === null) setNav('profile');
            else goTo('profile', { profileId });
          }}
        />
      </div>

      <div style={{ display: nav === 'messages' ? 'block' : 'none' }}>
        <MessagesScreen onOpenChat={convId => goTo('chat', { convId })} onLogout={handleLogout} />
      </div>

      <div style={{ display: nav === 'profile' ? 'block' : 'none' }}>
        <ProfileScreen profileId={null} onBack={() => setNav('discover')} onLogout={handleLogout} />
      </div>

      <BottomNav active={nav} onNav={handleNavChange} />
    </div>
  );
}
