import React, { useState } from 'react';
import { Icon } from '../components/UI.jsx';
import { login, register } from '../api.js';

export default function AuthScreen({ onAuthSuccess }) {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    age: '',
    gender: 'M',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setError(null);
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await login(formData.email, formData.password);
      if (res.success || res.data?.token) {
        localStorage.setItem('userId', res.data.user.id);
        onAuthSuccess(res.data.user);
      } else {
        setError(res.error || 'Login failed');
      }
    } catch (err) {
      setError(err.message || 'Network error');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!formData.firstName || !formData.lastName) {
      setError('First and last name required');
      setLoading(false);
      return;
    }
    if (!formData.age || formData.age < 18) {
      setError('Must be 18+');
      setLoading(false);
      return;
    }

    try {
      const res = await register(
        formData.email,
        formData.password,
        formData.firstName,
        formData.lastName,
        parseInt(formData.age),
        formData.gender
      );
      if (res.data?.token) {
        localStorage.setItem('userId', res.data.user.id);
        onAuthSuccess(res.data.user);
      } else {
        setError(res.error || 'Registration failed');
      }
    } catch (err) {
      setError(err.message || 'Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 relative overflow-hidden">
      {/* Gradient background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full" style={{
          background: 'radial-gradient(circle, rgba(255,86,44,0.15) 0%, transparent 70%)',
          filter: 'blur(40px)',
        }} />
        <div className="absolute bottom-0 left-0 w-96 h-96 rounded-full" style={{
          background: 'radial-gradient(circle, rgba(205,189,255,0.1) 0%, transparent 70%)',
          filter: 'blur(40px)',
        }} />
      </div>

      {/* Card */}
      <div className="w-full max-w-sm relative z-10 animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="font-display font-black italic tracking-tighter text-4xl text-gradient-brand mb-2">
            SMASH OR PASS
          </h1>
          <p className="text-on-surface-variant text-sm">Meet your match in seconds</p>
        </div>

        {/* Form container */}
        <div className="glass-card rounded-3xl p-6 border border-outline/10">
          {/* Tab switch */}
          <div className="flex gap-2 mb-6 bg-surface-container rounded-full p-1">
            {['login', 'register'].map(m => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(null); }}
                className={`flex-1 py-2 rounded-full font-display font-bold text-sm transition-all ${
                  mode === m
                    ? 'bg-primary-container text-on-primary-container'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                {m === 'login' ? 'Login' : 'Sign Up'}
              </button>
            ))}
          </div>

          <form onSubmit={mode === 'login' ? handleLogin : handleRegister} className="space-y-4">
            {mode === 'register' && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    name="firstName"
                    placeholder="First name"
                    value={formData.firstName}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl bg-surface-container text-on-surface placeholder-on-surface-variant/50 outline-none focus:ring-2 focus:ring-primary/30 transition-all"
                    required
                  />
                  <input
                    type="text"
                    name="lastName"
                    placeholder="Last name"
                    value={formData.lastName}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl bg-surface-container text-on-surface placeholder-on-surface-variant/50 outline-none focus:ring-2 focus:ring-primary/30 transition-all"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="number"
                    name="age"
                    placeholder="Age"
                    value={formData.age}
                    onChange={handleChange}
                    min="18"
                    max="100"
                    className="w-full px-4 py-3 rounded-xl bg-surface-container text-on-surface placeholder-on-surface-variant/50 outline-none focus:ring-2 focus:ring-primary/30 transition-all"
                    required
                  />
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-xl bg-surface-container text-on-surface outline-none focus:ring-2 focus:ring-primary/30 transition-all"
                  >
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </>
            )}

            <input
              type="email"
              name="email"
              placeholder="Email address"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl bg-surface-container text-on-surface placeholder-on-surface-variant/50 outline-none focus:ring-2 focus:ring-primary/30 transition-all"
              required
            />

            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl bg-surface-container text-on-surface placeholder-on-surface-variant/50 outline-none focus:ring-2 focus:ring-primary/30 transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface transition-colors"
              >
                <Icon name={showPassword ? 'visibility_off' : 'visibility'} size={18} />
              </button>
            </div>

            {/* Error message */}
            {error && (
              <div className="px-4 py-3 rounded-xl bg-error-container/20 border border-error/30 flex items-center gap-2 text-error text-sm">
                <Icon name="error" size={16} />
                <span>{error}</span>
              </div>
            )}

            {/* Submit button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-primary-container text-on-primary-container font-display font-bold transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              style={{
                boxShadow: '0 0 20px rgba(255,86,44,0.3)',
              }}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-on-primary-container border-t-transparent rounded-full animate-spin" />
                  <span>{mode === 'login' ? 'Logging in...' : 'Creating account...'}</span>
                </>
              ) : (
                <>
                  <Icon name={mode === 'login' ? 'login' : 'person_add'} size={18} />
                  <span>{mode === 'login' ? 'Login' : 'Create Account'}</span>
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-outline/20" />
            <span className="text-on-surface-variant text-xs">OR</span>
            <div className="flex-1 h-px bg-outline/20" />
          </div>

          {/* Social login (demo) */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              className="py-3 rounded-xl border border-outline/20 text-on-surface hover:bg-surface-container transition-all active:scale-95"
            >
              <Icon name="login" size={20} />
            </button>
            <button
              type="button"
              className="py-3 rounded-xl border border-outline/20 text-on-surface hover:bg-surface-container transition-all active:scale-95"
            >
              <Icon name="person" size={20} />
            </button>
          </div>

          {/* Terms */}
          <p className="text-center text-on-surface-variant text-xs mt-5 leading-relaxed">
            By continuing, you agree to our{' '}
            <button className="text-primary hover:underline">Terms</button> and{' '}
            <button className="text-primary hover:underline">Privacy Policy</button>
          </p>
        </div>

        {/* Demo credentials hint */}
        <p className="text-center text-on-surface-variant text-xs mt-6">
          Demo: test@example.com / password123
        </p>
      </div>
    </div>
  );
}
