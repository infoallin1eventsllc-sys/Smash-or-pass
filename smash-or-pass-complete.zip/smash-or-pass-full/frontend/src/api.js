import io from 'socket.io-client';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:5000';

let socket = null;
let token = localStorage.getItem('token');

// Initialize socket connection
export const initSocket = (userId) => {
  if (socket?.connected) return socket;
  
  socket = io(WS_URL, {
    auth: { token },
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
  });

  socket.on('connect', () => {
    console.log('Socket connected');
    socket.emit('user:join', userId);
  });

  socket.on('disconnect', () => {
    console.log('Socket disconnected');
  });

  return socket;
};

export const getSocket = () => socket;

// ====== AUTH ======
export const register = async (email, password, firstName, lastName, age, gender) => {
  const res = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, firstName, lastName, age, gender }),
  });
  const data = await res.json();
  if (data.token) {
    localStorage.setItem('token', data.token);
    token = data.token;
  }
  return data;
};

export const login = async (email, password) => {
  const res = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  if (data.data?.token) {
    localStorage.setItem('token', data.data.token);
    token = data.data.token;
  }
  return data;
};

const getHeaders = () => ({
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${token}`,
});

// ====== USERS ======
export const getUser = async (userId) => {
  const res = await fetch(`${API_URL}/users/${userId}`, {
    headers: getHeaders(),
  });
  return res.json();
};

export const updateUser = async (userId, data) => {
  const res = await fetch(`${API_URL}/users/${userId}`, {
    method: 'PATCH',
    headers: getHeaders(),
    body: JSON.stringify(data),
  });
  return res.json();
};

export const getDiscoverFeed = async () => {
  const res = await fetch(`${API_URL}/users/discover/feed`, {
    headers: getHeaders(),
  });
  return res.json();
};

// ====== SWIPES ======
export const swipe = async (targetId, action) => {
  const res = await fetch(`${API_URL}/swipes`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({ targetId, action }),
  });
  return res.json();
};

// ====== CONVERSATIONS ======
export const getConversations = async () => {
  const res = await fetch(`${API_URL}/conversations`, {
    headers: getHeaders(),
  });
  return res.json();
};

export const getMessages = async (convId) => {
  const res = await fetch(`${API_URL}/conversations/${convId}/messages`, {
    headers: getHeaders(),
  });
  return res.json();
};

export const sendMessage = async (convId, text, image = null) => {
  const res = await fetch(`${API_URL}/conversations/${convId}/messages`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({ text, image }),
  });
  return res.json();
};

export const markMessageRead = async (messageId) => {
  const res = await fetch(`${API_URL}/messages/${messageId}/read`, {
    method: 'PATCH',
    headers: getHeaders(),
  });
  return res.json();
};

export const reactToMessage = async (messageId, emoji) => {
  const res = await fetch(`${API_URL}/messages/${messageId}/reaction`, {
    method: 'PATCH',
    headers: getHeaders(),
    body: JSON.stringify({ emoji }),
  });
  return res.json();
};

// ====== SAFETY ======
export const blockUser = async (userId) => {
  const res = await fetch(`${API_URL}/users/${userId}/block`, {
    method: 'POST',
    headers: getHeaders(),
  });
  return res.json();
};

export const unblockUser = async (userId) => {
  const res = await fetch(`${API_URL}/users/${userId}/unblock`, {
    method: 'POST',
    headers: getHeaders(),
  });
  return res.json();
};

export const reportUser = async (reportedUserId, reason, description) => {
  const res = await fetch(`${API_URL}/reports`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({ reportedUserId, reason, description }),
  });
  return res.json();
};
