# Deploy to Vercel + Render/Railway (Backend)

Vercel hosts the frontend, Render/Railway hosts the backend.

## Frontend on Vercel

1. **Push to GitHub** with frontend code

2. **Go to vercel.com** → New Project → Import Git Repo

3. **Select `frontend` folder** as root:
   - Framework: Vite
   - Root Directory: `frontend`

4. **Set environment variables**:
   ```
   VITE_API_URL=https://your-backend.onrender.com/api
   VITE_WS_URL=https://your-backend.onrender.com
   ```

5. **Deploy** → Copy your Vercel URL

## Backend on Render

1. **Go to render.com** → New → Web Service

2. **Connect GitHub repo**

3. **Configure**:
   - Root Directory: `backend`
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Environment: Node

4. **Add environment variables**:
   ```
   JWT_SECRET=your-secret-key
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/smash-or-pass
   FRONTEND_URL=https://your-app.vercel.app
   NODE_ENV=production
   ```

5. **Create MongoDB Atlas** (free tier):
   - mongodb.com/atlas → Create Cluster
   - Copy connection string → MONGODB_URI
   - Add IP 0.0.0.0/0 to network access

6. **Deploy**

## Update Frontend Environment

Edit `frontend/vercel.json`:
```json
{
  "env": {
    "VITE_API_URL": "@api_url",
    "VITE_WS_URL": "@api_url"
  }
}
```

Then redeploy to Vercel.

## Result
- Frontend: https://your-app.vercel.app
- Backend: https://your-backend.onrender.com
- Both auto-deploy on git push
