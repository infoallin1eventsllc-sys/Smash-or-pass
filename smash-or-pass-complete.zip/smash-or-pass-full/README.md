# SMASH OR PASS - Complete Setup Guide

A full-stack dating app with real-time messaging, swiping, and matching. Production-ready with Docker, WebSocket, and MongoDB.

## 🎯 What's Included

- **5 Beautiful Screens**: Discover, Match, Messages, Chat, Profile
- **Real-time Features**: WebSocket messaging, typing indicators, reactions
- **Backend API**: Express.js + MongoDB + Socket.io
- **Authentication**: JWT-based login/register
- **Safety**: Block/report users, verified accounts
- **Deployment**: Docker, CI/CD, Railway/Vercel/AWS guides

## 📁 Project Structure

```
smash-or-pass-full/
├── backend/           # Express API + WebSocket
│   ├── src/
│   │   ├── server.js     # Express setup
│   │   ├── models.js     # MongoDB schemas
│   │   ├── routes.js     # API endpoints
│   │   ├── websocket.js  # Real-time events
│   │   └── utils.js      # Auth, helpers
│   ├── package.json
│   └── Dockerfile
├── frontend/          # React + Vite
│   ├── src/
│   │   ├── screens/     # All 5 screens
│   │   ├── components/  # UI components
│   │   ├── api.js       # API client
│   │   ├── data.js      # Mock data
│   │   └── App.jsx      # Main app
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml    # Full stack setup
├── .github/workflows/    # CI/CD pipeline
└── DEPLOY_*.md          # Deployment guides
```

## 🚀 Quick Start (5 minutes)

### Local Development

**Terminal 1 - Backend:**
```bash
cd backend
cp .env.example .env
npm install
npm run dev
# Runs on http://localhost:5000
```

**Terminal 2 - Frontend:**
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
# Runs on http://localhost:5173
```

**Terminal 3 - MongoDB** (optional, using Docker):
```bash
docker run -d -p 27017:27017 -e MONGO_INITDB_ROOT_USERNAME=root -e MONGO_INITDB_ROOT_PASSWORD=password mongo:7.0
```

Then update `backend/.env`:
```
MONGODB_URI=mongodb://root:password@localhost:27017/smash-or-pass?authSource=admin
```

### With Docker Compose (Recommended)

```bash
docker compose up -d --build

# Services:
# Frontend: http://localhost:3000
# Backend API: http://localhost:5000
# MongoDB: localhost:27017
```

Stop everything:
```bash
docker compose down
```

## 🔐 Authentication

### Default Test Account
- Email: `test@example.com`
- Password: `password123`

### Create New Account
1. Click "Sign Up" on auth screen
2. Fill in details (18+ only)
3. Create password
4. Auto-logs in with JWT token

## 📱 Features

### Discover Screen
- Swipe cards left (PASS) or right (SMASH)
- Drag to preview action
- Stack effect for multiple profiles
- View full profile by clicking info icon

### Match Screen
- Confetti animation on mutual match
- Option to message or keep swiping
- Floating hearts decoration

### Messages Screen
- Inbox with unread indicators
- Group chat preview
- FAB to start new conversation
- Online status indicators

### Chat Screen
- Real-time messaging with WebSocket
- Typing indicators (bouncing dots)
- Double-tap to react with emoji
- Read receipts (✓✓)
- View user profile from chat

### Profile Screen
- Photo gallery with dot navigation
- Bio, tags, verification badge
- Distance and online status
- Personal stats (own profile)
- Edit profile button
- Smash/Pass/Message actions

## 🔧 Backend API Endpoints

### Auth
```
POST /api/auth/register      # Create account
POST /api/auth/login         # Login
```

### Users
```
GET  /api/users/:id          # Get profile
PATCH /api/users/:id         # Update profile
GET  /api/users/discover/feed # Get nearby users
```

### Swipes
```
POST /api/swipes             # Like or pass (action: 'like'|'pass')
```

### Conversations
```
GET  /api/conversations                  # List conversations
GET  /api/conversations/:convId/messages # Get messages
POST /api/conversations/:convId/messages # Send message
PATCH /api/messages/:msgId/read          # Mark as read
PATCH /api/messages/:msgId/reaction      # Add reaction
```

### Safety
```
POST /api/users/:id/block    # Block user
POST /api/users/:id/unblock  # Unblock user
POST /api/reports            # Report user
```

## 🌐 WebSocket Events

Client → Server:
```javascript
socket.emit('user:join', userId)
socket.emit('typing:start', convId)
socket.emit('typing:stop', convId)
socket.emit('message:send', { conversationId, text, image })
socket.emit('message:read', messageId)
socket.emit('message:react', { messageId, emoji })
socket.emit('match:notify', { userId })
```

Server → Client:
```javascript
socket.on('message:new', message)
socket.on('typing:status', { convId, userId, typing })
socket.on('message:marked-read', messageId)
socket.on('message:reaction', { messageId, emoji })
socket.on('match:new', { matchedWith })
socket.on('user:online', { userId, online })
socket.on('user:offline', { userId })
```

## 🗄️ Database Schema

### Users
- email, password (hashed)
- firstName, lastName, age, gender
- avatar, photos, bio, tags
- location (GeoJSON for distance)
- preferences (age range, distance, gender interest)
- blocked, reported arrays
- online status, lastSeen timestamp

### Matches
- user1, user2
- mutualLike boolean
- conversation reference
- matchedAt timestamp

### Messages
- conversation ID
- sender ID
- text content
- image URL
- reaction emoji
- read status & timestamp

### Conversations
- participants array
- lastMessage reference
- unreadCount map

### Swipes
- user ID
- target ID
- action ('like' | 'pass')

### Reports
- reportedBy, reportedUser
- reason, description
- status ('pending' | 'reviewed' | 'resolved')

## 🚀 Deployment Options

### Option 1: Railway (Easiest, Recommended)
See `DEPLOY_RAILWAY.md` - Auto-deploy from GitHub in 5 minutes

### Option 2: Vercel + Render
See `DEPLOY_VERCEL.md` - Frontend on Vercel, Backend on Render

### Option 3: AWS (Production)
See `DEPLOY_AWS.md` - ECS, RDS, CloudFront, Route 53, Auto-scaling

### Option 4: Self-hosted (VPS)
```bash
# On your VPS:
git clone your-repo
cd your-repo
docker compose up -d

# Configure nginx reverse proxy
# Set up SSL with Let's Encrypt
# Configure domain DNS
```

## 📊 Environment Variables

### Backend (.env)
```
PORT=5000
NODE_ENV=production
MONGODB_URI=mongodb+srv://...
JWT_SECRET=your-super-secret-key
JWT_EXPIRE=7d
FRONTEND_URL=https://your-frontend.com
API_URL=https://your-api.com
CLOUDINARY_NAME=your-cloudinary
CLOUDINARY_API_KEY=xxx
CLOUDINARY_API_SECRET=xxx
SMTP_HOST=smtp.resend.com
SMTP_USER=your-email
SMTP_PASS=your-password
```

### Frontend (.env)
```
VITE_API_URL=https://your-api.com/api
VITE_WS_URL=https://your-api.com
```

## 🧪 Testing

### Backend Tests
```bash
cd backend
npm test
```

### E2E Tests (Frontend)
```bash
cd frontend
npm run test:e2e
```

## 📈 Performance & Scaling

- **Frontend**: CDN cache, lazy loading, code splitting
- **Backend**: Connection pooling, Redis caching, indexed queries
- **Database**: Geospatial indexing for distance queries
- **WebSocket**: Horizontal scaling with Redis pub/sub

## 🔐 Security Checklist

- [x] Password hashing (bcrypt)
- [x] JWT token auth
- [x] HTTPS/SSL enforced
- [x] CORS properly configured
- [x] Rate limiting on API
- [x] Input validation (Joi)
- [x] MongoDB injection protection
- [x] XSS prevention
- [ ] 2FA (optional)
- [ ] Rate limit for swipes (prevent abuse)
- [ ] Image moderation (for avatars)
- [ ] Age verification

## 📱 Responsive Design

- Mobile-first (tested on iPhone, Android)
- Works on tablets and desktop
- Touch gestures optimized
- Safe area padding for notches

## 🛠️ Common Issues

### WebSocket connection fails
- Check CORS in backend
- Ensure frontend & backend URLs match
- Check firewall ports (5000, 3000)

### MongoDB connection error
- Verify MONGODB_URI format
- Check network access (whitelist IP 0.0.0.0/0 in Atlas)
- Test with `mongosh` CLI

### Messages not loading
- Check API response in network tab
- Verify JWT token is valid
- Check conversation ID in URL

### Can't register/login
- Check email isn't already registered
- Verify password is 6+ characters
- Check backend logs for errors

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repo
2. Create feature branch
3. Commit changes
4. Push and create PR

## 📝 License

MIT - See LICENSE file

## 📧 Support

- GitHub Issues for bugs
- Discussions for feature requests
- Email: support@example.com

## 🎉 Next Steps

1. **Deploy**: Choose Railway/Vercel/AWS (see guides)
2. **Customize**: Update colors, fonts, copy
3. **Add Features**: In-app purchases, verified badges, super-likes
4. **Analytics**: Integrate Mixpanel or Amplitude
5. **Push Notifications**: Firebase Cloud Messaging
6. **Monetization**: Subscription tiers, premium features

Happy coding! 🚀
