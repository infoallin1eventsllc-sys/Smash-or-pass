import jwt from 'jsonwebtoken';
import bcryptjs from 'bcryptjs';

// Auth middleware
export const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// Generate JWT
export const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE });
};

// Compare passwords
export const comparePassword = (plain, hashed) => {
  return bcryptjs.compare(plain, hashed);
};

// Validation
export const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

// Error handler
export const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// API response formatter
export const sendSuccess = (res, data, statusCode = 200) => {
  res.status(statusCode).json({ success: true, data });
};

export const sendError = (res, message, statusCode = 400) => {
  res.status(statusCode).json({ success: false, error: message });
};

// Geospatial distance calculation
export const getDistance = (coords1, coords2) => {
  const R = 6371; // Earth radius in km
  const dLat = ((coords2[1] - coords1[1]) * Math.PI) / 180;
  const dLng = ((coords2[0] - coords1[0]) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((coords1[1] * Math.PI) / 180) *
      Math.cos((coords2[1] * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};
