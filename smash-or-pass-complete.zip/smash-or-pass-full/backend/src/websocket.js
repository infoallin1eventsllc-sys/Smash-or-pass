import { Server } from 'socket.io';
import { Message, User, Conversation } from './models.js';

export const setupWebSocket = (httpServer) => {
  const io = new Server(httpServer, {
    cors: {
      origin: process.env.FRONTEND_URL,
      credentials: true,
    },
  });

  const userSockets = new Map(); // userId -> socketId

  io.on('connection', (socket) => {
    console.log(`User connected: ${socket.id}`);

    // User joins (register socket)
    socket.on('user:join', async (userId) => {
      userSockets.set(userId, socket.id);
      socket.userId = userId;
      
      // Update user online status
      await User.findByIdAndUpdate(userId, { online: true, lastSeen: Date.now() });
      
      // Join personal room
      socket.join(`user:${userId}`);
      
      // Broadcast user online
      io.emit('user:online', { userId, online: true });
    });

    // Typing indicator
    socket.on('typing:start', (convId) => {
      socket.broadcast.emit('typing:status', {
        convId,
        userId: socket.userId,
        typing: true,
      });
    });

    socket.on('typing:stop', (convId) => {
      socket.broadcast.emit('typing:status', {
        convId,
        userId: socket.userId,
        typing: false,
      });
    });

    // Send message (real-time)
    socket.on('message:send', async (data) => {
      try {
        const { conversationId, text, image } = data;

        // Save to DB
        const msg = new Message({
          conversation: conversationId,
          sender: socket.userId,
          text,
          image,
        });
        await msg.save();
        await msg.populate('sender', 'firstName lastName avatar');

        // Get conversation to find other user
        const conv = await Conversation.findById(conversationId);
        const otherUser = conv.participants.find(p => p.toString() !== socket.userId);

        // Send to recipient & sender
        io.emit('message:new', {
          conversationId,
          message: msg,
        });

        // Update conversation
        await Conversation.findByIdAndUpdate(conversationId, {
          lastMessage: msg._id,
          lastMessageText: text,
          updatedAt: Date.now(),
        });
      } catch (err) {
        socket.emit('message:error', { error: err.message });
      }
    });

    // Message read
    socket.on('message:read', async (messageId) => {
      await Message.findByIdAndUpdate(messageId, {
        read: true,
        readAt: Date.now(),
      });
      io.emit('message:marked-read', { messageId });
    });

    // Reaction
    socket.on('message:react', async (data) => {
      const { messageId, emoji } = data;
      await Message.findByIdAndUpdate(messageId, { reaction: emoji });
      io.emit('message:reaction', { messageId, emoji });
    });

    // Match notification
    socket.on('match:notify', async (data) => {
      const { userId } = data;
      const targetSocket = userSockets.get(userId);
      if (targetSocket) {
        io.to(targetSocket).emit('match:new', {
          matchedWith: socket.userId,
          timestamp: Date.now(),
        });
      }
    });

    // Disconnect
    socket.on('disconnect', async () => {
      userSockets.delete(socket.userId);
      if (socket.userId) {
        await User.findByIdAndUpdate(socket.userId, {
          online: false,
          lastSeen: Date.now(),
        });
        io.emit('user:offline', { userId: socket.userId });
      }
      console.log(`User disconnected: ${socket.id}`);
    });
  });

  return io;
};
