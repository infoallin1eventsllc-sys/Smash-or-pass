import express from 'express';
import { User, Swipe, Match, Conversation, Message } from './models.js';
import {
  authMiddleware,
  generateToken,
  comparePassword,
  asyncHandler,
  sendSuccess,
  sendError,
  getDistance,
} from './utils.js';

const router = express.Router();

// ====== AUTH ROUTES ======

// Register
router.post('/auth/register', asyncHandler(async (req, res) => {
  const { email, password, firstName, lastName, age, gender } = req.body;

  if (!email || !password || !firstName || !lastName || !age || !gender) {
    return sendError(res, 'Missing required fields', 400);
  }

  const existing = await User.findOne({ email });
  if (existing) return sendError(res, 'Email already registered', 400);

  const user = new User({ email, password, firstName, lastName, age, gender });
  await user.save();

  const token = generateToken(user._id);
  sendSuccess(res, {
    user: { id: user._id, email: user.email, firstName, lastName, age, gender },
    token,
  }, 201);
}));

// Login
router.post('/auth/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return sendError(res, 'Email and password required', 400);

  const user = await User.findOne({ email });
  if (!user) return sendError(res, 'Invalid credentials', 401);

  const valid = await comparePassword(password, user.password);
  if (!valid) return sendError(res, 'Invalid credentials', 401);

  const token = generateToken(user._id);
  user.online = true;
  await user.save();

  sendSuccess(res, {
    user: {
      id: user._id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      avatar: user.avatar,
      verified: user.verified,
    },
    token,
  });
}));

// ====== USER ROUTES ======

// Get profile
router.get('/users/:id', asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');
  if (!user) return sendError(res, 'User not found', 404);
  sendSuccess(res, user);
}));

// Update profile
router.patch('/users/:id', authMiddleware, asyncHandler(async (req, res) => {
  if (req.userId !== req.params.id) return sendError(res, 'Unauthorized', 403);

  const { firstName, lastName, bio, tags, avatar, photos, location, age, gender } = req.body;
  const user = await User.findByIdAndUpdate(
    req.params.id,
    { firstName, lastName, bio, tags, avatar, photos, location, age, gender, updatedAt: Date.now() },
    { new: true }
  ).select('-password');

  sendSuccess(res, user);
}));

// Get discover feed (nearby users)
router.get('/users/discover/feed', authMiddleware, asyncHandler(async (req, res) => {
  const user = await User.findById(req.userId);
  if (!user) return sendError(res, 'User not found', 404);

  // Get users already swiped on
  const swiped = await Swipe.find({ user: req.userId }).select('target');
  const swipedIds = swiped.map(s => s.target);

  // Find nearby users matching preferences
  const candidates = await User.find({
    _id: { $nin: [req.userId, ...swipedIds, ...user.blocked] },
    age: { $gte: user.preferences.ageMin, $lte: user.preferences.ageMax },
    gender: { $in: user.preferences.genderInterest },
  }).limit(20);

  // Filter by distance if location available
  const filtered = candidates.filter(c => {
    if (!user.location || !c.location) return true;
    const dist = getDistance(user.location.coordinates, c.location.coordinates);
    return dist <= user.preferences.distanceMax;
  });

  sendSuccess(res, filtered);
}));

// ====== SWIPE ROUTES ======

// Like/Pass
router.post('/swipes', authMiddleware, asyncHandler(async (req, res) => {
  const { targetId, action } = req.body; // action: 'like' or 'pass'

  if (!['like', 'pass'].includes(action)) {
    return sendError(res, 'Invalid action', 400);
  }

  // Record the swipe
  const swipe = new Swipe({ user: req.userId, target: targetId, action });
  await swipe.save();

  if (action === 'like') {
    // Check if target also liked this user
    const targetSwipe = await Swipe.findOne({ user: targetId, target: req.userId, action: 'like' });
    if (targetSwipe) {
      // Mutual match!
      const match = new Match({ user1: req.userId, user2: targetId, mutualLike: true });
      await match.save();

      // Create conversation
      const conv = new Conversation({
        participants: [req.userId, targetId],
        unreadCount: new Map([[req.userId, 0], [targetId, 0]]),
      });
      await conv.save();

      // Update match with conversation
      match.conversation = conv._id;
      await match.save();

      sendSuccess(res, { match: true, conversation: conv._id }, 201);
      return;
    }
  }

  sendSuccess(res, { match: false }, 201);
}));

// ====== MESSAGE ROUTES ======

// Get conversations
router.get('/conversations', authMiddleware, asyncHandler(async (req, res) => {
  const convs = await Conversation.find({ participants: req.userId })
    .populate('participants', '-password')
    .populate('lastMessage')
    .sort({ updatedAt: -1 });

  sendSuccess(res, convs);
}));

// Get messages in conversation
router.get('/conversations/:convId/messages', authMiddleware, asyncHandler(async (req, res) => {
  const msgs = await Message.find({ conversation: req.params.convId })
    .populate('sender', 'firstName lastName avatar')
    .sort({ createdAt: 1 });

  sendSuccess(res, msgs);
}));

// Send message
router.post('/conversations/:convId/messages', authMiddleware, asyncHandler(async (req, res) => {
  const { text, image } = req.body;

  const msg = new Message({
    conversation: req.params.convId,
    sender: req.userId,
    text,
    image,
  });
  await msg.save();
  await msg.populate('sender', 'firstName lastName avatar');

  // Update conversation
  await Conversation.findByIdAndUpdate(req.params.convId, {
    lastMessage: msg._id,
    lastMessageText: text,
    updatedAt: Date.now(),
  });

  sendSuccess(res, msg, 201);
}));

// Mark as read
router.patch('/messages/:msgId/read', authMiddleware, asyncHandler(async (req, res) => {
  const msg = await Message.findByIdAndUpdate(
    req.params.msgId,
    { read: true, readAt: Date.now() },
    { new: true }
  );
  sendSuccess(res, msg);
}));

// React to message
router.patch('/messages/:msgId/reaction', authMiddleware, asyncHandler(async (req, res) => {
  const { emoji } = req.body;
  const msg = await Message.findByIdAndUpdate(
    req.params.msgId,
    { reaction: emoji },
    { new: true }
  );
  sendSuccess(res, msg);
}));

// ====== SAFETY ROUTES ======

// Block user
router.post('/users/:id/block', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  const user = await User.findByIdAndUpdate(
    req.userId,
    { $addToSet: { blocked: id } },
    { new: true }
  );
  sendSuccess(res, { blocked: true });
}));

// Unblock user
router.post('/users/:id/unblock', authMiddleware, asyncHandler(async (req, res) => {
  const { id } = req.params;
  const user = await User.findByIdAndUpdate(
    req.userId,
    { $pull: { blocked: id } },
    { new: true }
  );
  sendSuccess(res, { blocked: false });
}));

// Report user
router.post('/reports', authMiddleware, asyncHandler(async (req, res) => {
  const { reportedUserId, reason, description } = req.body;
  const report = new Report({
    reportedBy: req.userId,
    reportedUser: reportedUserId,
    reason,
    description,
  });
  await report.save();
  sendSuccess(res, { reported: true }, 201);
}));

export default router;
