import mongoose from 'mongoose';
import bcryptjs from 'bcryptjs';

// User Schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6 },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  age: { type: Number, required: true, min: 18, max: 100 },
  gender: { type: String, enum: ['M', 'F', 'Other'], required: true },
  avatar: { type: String }, // Cloudinary URL
  photos: [{ type: String }], // Array of photo URLs
  bio: { type: String, maxlength: 500 },
  tags: [{ type: String }],
  location: { type: { type: String, default: 'Point' }, coordinates: [Number] }, // GeoJSON
  verified: { type: Boolean, default: false },
  verifiedAt: { type: Date },
  online: { type: Boolean, default: false },
  lastSeen: { type: Date, default: Date.now },
  preferences: {
    ageMin: { type: Number, default: 18 },
    ageMax: { type: Number, default: 50 },
    distanceMax: { type: Number, default: 50 }, // km
    genderInterest: [{ type: String }],
  },
  blocked: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  reported: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

// Hash password before save
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcryptjs.hash(this.password, 10);
  next();
});

// Index for geospatial queries
userSchema.index({ 'location': '2dsphere' });

// Match Schema
const matchSchema = new mongoose.Schema({
  user1: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  user2: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  mutualLike: { type: Boolean, default: false },
  matchedAt: { type: Date, default: Date.now },
  blocked: { type: Boolean, default: false },
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: 'Conversation' },
});

// Message Schema
const messageSchema = new mongoose.Schema({
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: 'Conversation', required: true },
  sender: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  text: { type: String, required: true },
  image: { type: String },
  reaction: { type: String }, // emoji
  read: { type: Boolean, default: false },
  readAt: { type: Date },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

// Conversation Schema
const conversationSchema = new mongoose.Schema({
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }],
  lastMessage: { type: mongoose.Schema.Types.ObjectId, ref: 'Message' },
  lastMessageText: { type: String },
  unreadCount: { type: Map, of: Number, default: new Map() },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

// Swipe Schema (to track likes/passes)
const swipeSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  target: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  action: { type: String, enum: ['like', 'pass'], required: true },
  createdAt: { type: Date, default: Date.now },
});

// Report Schema
const reportSchema = new mongoose.Schema({
  reportedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  reportedUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  reason: { type: String, enum: ['inappropriate', 'spam', 'fake', 'offensive', 'other'], required: true },
  description: { type: String },
  status: { type: String, enum: ['pending', 'reviewed', 'resolved'], default: 'pending' },
  createdAt: { type: Date, default: Date.now },
});

export const User = mongoose.model('User', userSchema);
export const Match = mongoose.model('Match', matchSchema);
export const Message = mongoose.model('Message', messageSchema);
export const Conversation = mongoose.model('Conversation', conversationSchema);
export const Swipe = mongoose.model('Swipe', swipeSchema);
export const Report = mongoose.model('Report', reportSchema);
